# Diseño del túnel WireGuard

Cada WISP tendrá un peer WireGuard propio, con claves independientes y una subred privada asignada por el servidor. El backend sólo accederá a la IP privada del router por el túnel.

Flujo recomendado:
1. El sistema genera un perfil/QR WireGuard exclusivo para el WISP.
2. El administrador importa el perfil en el MikroTik (RouterOS 7) y activa el peer.
3. El firewall del MikroTik permite TCP 8729 únicamente desde la IP WireGuard del servidor.
4. Se crea un usuario RouterOS API dedicado, sin grupo `full` y con permisos mínimos revisados para los comandos habilitados.
5. El panel prueba conectividad y guarda la contraseña cifrada en el backend.

No compartir claves privadas entre WISP. No exponer 8728/8729 a Internet. La automatización de alta de peers y la prueba real de API quedan para la siguiente iteración del módulo de infraestructura.
