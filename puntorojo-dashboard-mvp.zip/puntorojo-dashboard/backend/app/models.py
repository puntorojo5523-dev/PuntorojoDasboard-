from sqlalchemy import String, Integer, Boolean, ForeignKey, DateTime, Numeric, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

class Wisp(Base):
    __tablename__ = 'wisps'
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(140))
    slug: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    owner_email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now())

class User(Base):
    __tablename__ = 'users'
    id: Mapped[int] = mapped_column(primary_key=True)
    wisp_id: Mapped[int] = mapped_column(ForeignKey('wisps.id'), index=True)
    email: Mapped[str] = mapped_column(String(255), index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(30), default='owner')
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Router(Base):
    __tablename__ = 'routers'
    id: Mapped[int] = mapped_column(primary_key=True)
    wisp_id: Mapped[int] = mapped_column(ForeignKey('wisps.id'), index=True)
    name: Mapped[str] = mapped_column(String(120))
    wg_address: Mapped[str] = mapped_column(String(64))
    api_port: Mapped[int] = mapped_column(Integer, default=8729)
    api_user: Mapped[str] = mapped_column(String(80))
    encrypted_api_password: Mapped[str] = mapped_column(Text)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)

class Plan(Base):
    __tablename__ = 'plans'
    id: Mapped[int] = mapped_column(primary_key=True)
    wisp_id: Mapped[int] = mapped_column(ForeignKey('wisps.id'), index=True)
    name: Mapped[str] = mapped_column(String(100))
    upload_mbps: Mapped[int] = mapped_column(Integer)
    download_mbps: Mapped[int] = mapped_column(Integer)
    price: Mapped[float] = mapped_column(Numeric(10,2))
    currency: Mapped[str] = mapped_column(String(3), default='DOP')
    mikrotik_profile: Mapped[str] = mapped_column(String(100))
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Customer(Base):
    __tablename__ = 'customers'
    id: Mapped[int] = mapped_column(primary_key=True)
    wisp_id: Mapped[int] = mapped_column(ForeignKey('wisps.id'), index=True)
    plan_id: Mapped[int | None] = mapped_column(ForeignKey('plans.id'), nullable=True)
    router_id: Mapped[int | None] = mapped_column(ForeignKey('routers.id'), nullable=True)
    full_name: Mapped[str] = mapped_column(String(160))
    pppoe_username: Mapped[str] = mapped_column(String(100))
    service_status: Mapped[str] = mapped_column(String(20), default='active')
    phone: Mapped[str | None] = mapped_column(String(30), nullable=True)
