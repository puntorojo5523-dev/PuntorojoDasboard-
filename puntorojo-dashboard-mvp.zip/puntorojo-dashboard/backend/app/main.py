from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from jose import jwt, JWTError
import os, re
from .db import Base, engine, get_db
from . import models
from .security import hash_password, verify_password, create_token, JWT_SECRET, JWT_ALG, encrypt_secret

Base.metadata.create_all(bind=engine)
app = FastAPI(title='PuntoRojo Dashboard API', version='0.1.0', description='API multi-WISP para administración ISP')
oauth = OAuth2PasswordBearer(tokenUrl='/auth/login')

class RegisterIn(BaseModel):
    company_name: str = Field(min_length=2, max_length=140)
    slug: str = Field(min_length=3, max_length=80, pattern=r'^[a-z0-9-]+$')
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class RouterIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    wg_address: str
    api_port: int = Field(default=8729, ge=1, le=65535)
    api_user: str
    api_password: str = Field(min_length=12, max_length=256)

class PlanIn(BaseModel):
    name: str
    upload_mbps: int = Field(gt=0, le=100000)
    download_mbps: int = Field(gt=0, le=100000)
    price: float = Field(ge=0)
    currency: str = 'DOP'
    mikrotik_profile: str

class CustomerIn(BaseModel):
    full_name: str
    pppoe_username: str
    plan_id: int | None = None
    router_id: int | None = None
    phone: str | None = None

@app.get('/health')
def health():
    return {'status':'ok','service':'puntorojo-dashboard-api','version':'0.1.0'}

@app.post('/auth/register', status_code=201)
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if db.query(models.Wisp).filter((models.Wisp.slug == data.slug) | (models.Wisp.owner_email == data.email)).first():
        raise HTTPException(409, 'La empresa o el correo ya están registrados')
    wisp = models.Wisp(name=data.company_name, slug=data.slug, owner_email=data.email)
    db.add(wisp); db.flush()
    user = models.User(wisp_id=wisp.id, email=data.email, password_hash=hash_password(data.password), role='owner')
    db.add(user); db.commit(); db.refresh(user)
    return {'access_token':create_token(user.id,wisp.id,user.role),'token_type':'bearer','company':{'id':wisp.id,'name':wisp.name,'slug':wisp.slug}}

@app.post('/auth/login')
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == data.email, models.User.active == True).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, 'Correo o contraseña incorrectos')
    return {'access_token':create_token(user.id,user.wisp_id,user.role),'token_type':'bearer'}

def current_user(token: str = Depends(oauth), db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
        user_id, wisp_id = int(payload['sub']), int(payload['wisp_id'])
    except (JWTError, KeyError, ValueError):
        raise HTTPException(401, 'Sesión inválida')
    user = db.query(models.User).filter_by(id=user_id, wisp_id=wisp_id, active=True).first()
    if not user: raise HTTPException(401, 'Usuario no disponible')
    return user

@app.get('/dashboard')
def dashboard(user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    wid = user.wisp_id
    return {'customers':db.query(models.Customer).filter_by(wisp_id=wid).count(), 'active_customers':db.query(models.Customer).filter_by(wisp_id=wid,service_status='active').count(), 'plans':db.query(models.Plan).filter_by(wisp_id=wid,active=True).count(), 'routers':db.query(models.Router).filter_by(wisp_id=wid,enabled=True).count()}

@app.get('/routers')
def list_routers(user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(models.Router).filter_by(wisp_id=user.wisp_id).all()
    return [{'id':r.id,'name':r.name,'wg_address':r.wg_address,'api_port':r.api_port,'api_user':r.api_user,'enabled':r.enabled} for r in rows]

@app.post('/routers', status_code=201)
def add_router(data: RouterIn, user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    # Solo se almacena la IP privada del peer WireGuard, nunca una IP pública abierta.
    if not re.fullmatch(r'(?:\d{1,3}\.){3}\d{1,3}', data.wg_address):
        raise HTTPException(400, 'Usa la dirección IPv4 privada asignada al peer WireGuard')
    row = models.Router(wisp_id=user.wisp_id,name=data.name,wg_address=data.wg_address,api_port=data.api_port,api_user=data.api_user,encrypted_api_password=encrypt_secret(data.api_password))
    db.add(row); db.commit(); db.refresh(row)
    return {'id':row.id,'name':row.name,'status':'registered','message':'Router registrado. Falta validar el túnel y la API antes de operar.'}

@app.get('/plans')
def list_plans(user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(models.Plan).filter_by(wisp_id=user.wisp_id).all()
    return [{'id':p.id,'name':p.name,'upload_mbps':p.upload_mbps,'download_mbps':p.download_mbps,'price':float(p.price),'currency':p.currency,'mikrotik_profile':p.mikrotik_profile,'active':p.active} for p in rows]

@app.post('/plans', status_code=201)
def add_plan(data: PlanIn, user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    row=models.Plan(wisp_id=user.wisp_id,**data.model_dump()); db.add(row); db.commit(); db.refresh(row)
    return {'id':row.id,'name':row.name}

@app.get('/customers')
def list_customers(user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    rows=db.query(models.Customer).filter_by(wisp_id=user.wisp_id).all()
    return [{'id':c.id,'full_name':c.full_name,'pppoe_username':c.pppoe_username,'plan_id':c.plan_id,'router_id':c.router_id,'status':c.service_status,'phone':c.phone} for c in rows]

@app.post('/customers', status_code=201)
def add_customer(data: CustomerIn, user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    if db.query(models.Customer).filter_by(wisp_id=user.wisp_id,pppoe_username=data.pppoe_username).first():
        raise HTTPException(409,'Ese usuario PPPoE ya existe en esta empresa')
    if data.plan_id and not db.query(models.Plan).filter_by(id=data.plan_id,wisp_id=user.wisp_id).first(): raise HTTPException(404,'Plan no encontrado')
    if data.router_id and not db.query(models.Router).filter_by(id=data.router_id,wisp_id=user.wisp_id).first(): raise HTTPException(404,'Router no encontrado')
    row=models.Customer(wisp_id=user.wisp_id,**data.model_dump()); db.add(row); db.commit(); db.refresh(row)
    return {'id':row.id,'pppoe_username':row.pppoe_username,'status':row.service_status}
