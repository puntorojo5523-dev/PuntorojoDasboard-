import os
from datetime import datetime, timedelta, timezone
from jose import jwt
from passlib.context import CryptContext
from cryptography.fernet import Fernet

pwd = CryptContext(schemes=['bcrypt'], deprecated='auto')
JWT_SECRET = os.getenv('JWT_SECRET', 'DEV_ONLY_CHANGE_THIS_SECRET')
JWT_ALG = 'HS256'

def hash_password(value: str) -> str:
    return pwd.hash(value)

def verify_password(value: str, hashed: str) -> bool:
    return pwd.verify(value, hashed)

def create_token(user_id: int, wisp_id: int, role: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=int(os.getenv('ACCESS_TOKEN_MINUTES', '720')))
    return jwt.encode({'sub': str(user_id), 'wisp_id': wisp_id, 'role': role, 'exp': exp}, JWT_SECRET, algorithm=JWT_ALG)

def cipher():
    key = os.getenv('FERNET_KEY')
    if not key:
        raise RuntimeError('FERNET_KEY no está configurada; no se pueden guardar secretos de routers.')
    return Fernet(key.encode())

def encrypt_secret(value: str) -> str:
    return cipher().encrypt(value.encode()).decode()
