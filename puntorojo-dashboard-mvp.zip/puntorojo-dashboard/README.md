# PUNTOROJO DASHBOARD

Plataforma multi-WISP para administrar clientes PPPoE, planes y routers MikroTik.

## Arquitectura
- `mobile/`: aplicación Android con Expo + React Native (TypeScript).
- `backend/`: API FastAPI, PostgreSQL, JWT y separación de datos por WISP.
- `deploy/`: despliegue inicial y plantilla de WireGuard.

La APK se genera con EAS Build (nube). Este entorno de trabajo no incluye Flutter ni Android SDK, por lo que no es posible compilar aquí un APK firmado. El proyecto incluye `eas.json` y los pasos para generarlo desde una cuenta Expo.

## Desarrollo local

### Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API: http://localhost:8000  |  Documentación: http://localhost:8000/docs

### Aplicación Android
Requiere Node.js y una cuenta Expo.
```bash
cd mobile
npm install
npx expo start
```
Para crear APK de prueba:
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build -p android --profile preview
```
EAS compila el APK en la nube y entrega un enlace de instalación.

## Seguridad de MikroTik
La aplicación móvil nunca almacena credenciales RouterOS ni se conecta directamente al router. El backend se conecta por la interfaz WireGuard privada del servidor al router del WISP. Cada router debe tener un usuario API exclusivo, con permisos mínimos y acceso limitado a la IP del servidor por el firewall.

No publicar los puertos API 8728/8729 en Internet. Usar WireGuard y RouterOS API-SSL (8729) dentro del túnel. Guardar `FERNET_KEY` fuera del repositorio.

## Estado del proyecto
Esqueleto inicial: interfaz móvil, API multiempresa, autenticación JWT, modelos de WISP/router/planes/clientes y estructura para conexión privada. Antes de producción faltan pruebas automatizadas, recuperación de contraseña, pagos, auditoría ampliada, rotación de secretos, monitoreo y despliegue endurecido.
