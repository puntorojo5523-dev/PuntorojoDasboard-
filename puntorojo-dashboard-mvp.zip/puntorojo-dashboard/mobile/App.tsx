import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';

const RED = '#D92336';
const API = 'https://API-DOMINIO-PENDIENTE';

type Tab = 'Inicio' | 'Clientes' | 'Planes' | 'Routers' | 'Cuenta';

export default function App() {
  const [tab, setTab] = useState<Tab>('Inicio');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [logged, setLogged] = useState(false);

  const tile = (label: string, value: string, hint: string) => (
    <View style={styles.metric} key={label}><Text style={styles.metricLabel}>{label}</Text><Text style={styles.metricValue}>{value}</Text><Text style={styles.muted}>{hint}</Text></View>
  );

  if (!logged) return (
    <SafeAreaView style={styles.safe}><StatusBar barStyle="dark-content" />
      <View style={styles.loginWrap}>
        <View style={styles.logo}><Text style={styles.logoIcon}>●</Text></View>
        <Text style={styles.brand}>PUNTOROJO</Text><Text style={styles.subtitle}>DASHBOARD · ISP MANAGEMENT</Text>
        <Text style={styles.heading}>Bienvenido</Text><Text style={styles.muted}>Administra tu proveedor de Internet</Text>
        <TextInput style={styles.input} placeholder="Correo electrónico" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail}/>
        <TextInput style={styles.input} placeholder="Contraseña" secureTextEntry value={password} onChangeText={setPassword}/>
        <TouchableOpacity style={styles.primary} onPress={() => { if (email.trim() && password.length >= 8) setLogged(true); }}><Text style={styles.primaryText}>Entrar a mi WISP</Text></TouchableOpacity>
        <Text style={styles.small}>Prototipo inicial: el inicio de sesión se conectará a la API al configurar el servidor.</Text>
      </View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={styles.safe}><StatusBar barStyle="dark-content" />
      <View style={styles.topbar}><View><Text style={styles.brandSmall}>PUNTOROJO</Text><Text style={styles.topTitle}>DASHBOARD</Text></View><View style={styles.avatar}><Text style={{color:'#fff',fontWeight:'800'}}>W</Text></View></View>
      <ScrollView contentContainerStyle={styles.content}>
        {tab === 'Inicio' && <>
          <Text style={styles.greeting}>Panel general</Text><Text style={styles.muted}>Resumen de tu proveedor</Text>
          <View style={styles.grid}>{tile('Clientes activos','—','Se carga desde el servidor')}{tile('Suspendidos','—','Estado de servicio')}{tile('Planes','—','Planes configurados')}{tile('Routers','—','Conexión WireGuard')}</View>
          <Text style={styles.section}>Accesos rápidos</Text>
          {['Registrar cliente PPPoE','Crear un plan de Internet','Conectar un MikroTik'].map((x,i)=><TouchableOpacity key={x} style={styles.action} onPress={()=>setTab(i===0?'Clientes':i===1?'Planes':'Routers')}><Text style={styles.actionText}>{x}</Text><Text style={styles.arrow}>›</Text></TouchableOpacity>)}
        </>}
        {tab === 'Clientes' && <><Text style={styles.greeting}>Clientes</Text><Text style={styles.muted}>Administración de cuentas PPPoE</Text><View style={styles.empty}><Text style={styles.emptyTitle}>Todavía no hay clientes</Text><Text style={styles.muted}>Aquí podrás crear, editar, suspender y reconectar usuarios PPPoE.</Text></View></>}
        {tab === 'Planes' && <><Text style={styles.greeting}>Planes de Internet</Text><Text style={styles.muted}>Velocidad, precio y perfil PPP</Text><View style={styles.empty}><Text style={styles.emptyTitle}>Configura tus planes</Text><Text style={styles.muted}>Define subida, bajada, precio y perfil de MikroTik.</Text></View></>}
        {tab === 'Routers' && <><Text style={styles.greeting}>Routers MikroTik</Text><Text style={styles.muted}>Conexión privada mediante WireGuard</Text><View style={styles.empty}><Text style={styles.emptyTitle}>Conecta tu primer MikroTik</Text><Text style={styles.muted}>El servidor establecerá el túnel WireGuard y accederá a RouterOS API-SSL por la red privada.</Text><View style={styles.notice}><Text style={styles.noticeText}>No introduzcas aquí credenciales reales todavía. Primero desplegaremos el servidor y emitiremos las claves del túnel.</Text></View></View></>}
        {tab === 'Cuenta' && <><Text style={styles.greeting}>Mi empresa</Text><Text style={styles.muted}>Cuenta del proveedor</Text><View style={styles.empty}><Text style={styles.emptyTitle}>Registro de WISP</Text><Text style={styles.muted}>El alta multiempresa y los planes de suscripción se habilitarán desde el backend.</Text><TouchableOpacity onPress={()=>setLogged(false)} style={[styles.primary,{marginTop:20}]}><Text style={styles.primaryText}>Cerrar sesión de demostración</Text></TouchableOpacity></View></>}
      </ScrollView>
      <View style={styles.nav}>{(['Inicio','Clientes','Planes','Routers','Cuenta'] as Tab[]).map(t=><TouchableOpacity key={t} onPress={()=>setTab(t)} style={styles.navItem}><Text style={[styles.navText,tab===t&&styles.navActive]}>{t}</Text></TouchableOpacity>)}</View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({safe:{flex:1,backgroundColor:'#F5F6F8'},loginWrap:{flex:1,justifyContent:'center',padding:26},logo:{width:64,height:64,borderRadius:20,backgroundColor:RED,alignItems:'center',justifyContent:'center',alignSelf:'center',marginBottom:14},logoIcon:{color:'#fff',fontSize:34},brand:{fontSize:24,fontWeight:'900',letterSpacing:2,textAlign:'center',color:'#171B29'},subtitle:{fontSize:10,letterSpacing:2,textAlign:'center',color:'#7A8190',marginBottom:44},heading:{fontSize:26,fontWeight:'800',color:'#171B29',marginBottom:5},muted:{color:'#7A8190',fontSize:13,lineHeight:19},input:{height:52,backgroundColor:'#fff',borderWidth:1,borderColor:'#E5E7EB',borderRadius:12,paddingHorizontal:15,marginTop:14,fontSize:15},primary:{height:52,backgroundColor:RED,borderRadius:12,alignItems:'center',justifyContent:'center',marginTop:20},primaryText:{color:'#fff',fontWeight:'800',fontSize:15},small:{fontSize:11,color:'#9096A2',textAlign:'center',marginTop:18,lineHeight:16},topbar:{height:72,backgroundColor:'#fff',paddingHorizontal:20,alignItems:'center',justifyContent:'space-between',flexDirection:'row',borderBottomWidth:1,borderBottomColor:'#ECEEF1'},brandSmall:{fontSize:11,fontWeight:'900',letterSpacing:2,color:RED},topTitle:{fontSize:17,fontWeight:'900',color:'#171B29',letterSpacing:1},avatar:{width:38,height:38,borderRadius:13,backgroundColor:'#242A39',alignItems:'center',justifyContent:'center'},content:{padding:20,paddingBottom:30},greeting:{fontSize:25,fontWeight:'900',color:'#171B29',marginBottom:4},grid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between',marginTop:20},metric:{width:'48%',backgroundColor:'#fff',padding:16,borderRadius:16,marginBottom:12,borderWidth:1,borderColor:'#ECEEF1'},metricLabel:{fontSize:12,color:'#7A8190'},metricValue:{fontSize:29,fontWeight:'900',color:'#171B29',marginVertical:8},section:{fontSize:17,fontWeight:'800',color:'#171B29',marginTop:16,marginBottom:10},action:{backgroundColor:'#fff',padding:17,borderRadius:13,marginBottom:9,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},actionText:{fontWeight:'700',color:'#252B39'},arrow:{fontSize:25,color:RED},empty:{backgroundColor:'#fff',padding:22,borderRadius:16,marginTop:22,borderWidth:1,borderColor:'#ECEEF1'},emptyTitle:{fontSize:17,fontWeight:'800',color:'#171B29',marginBottom:8},notice:{backgroundColor:'#FFF4E5',padding:13,borderRadius:10,marginTop:18},noticeText:{color:'#80551D',fontSize:12,lineHeight:18},nav:{height:66,backgroundColor:'#fff',borderTopWidth:1,borderTopColor:'#ECEEF1',flexDirection:'row',justifyContent:'space-around',alignItems:'center'},navItem:{padding:8},navText:{fontSize:11,color:'#858B97',fontWeight:'600'},navActive:{color:RED,fontWeight:'900'}});
